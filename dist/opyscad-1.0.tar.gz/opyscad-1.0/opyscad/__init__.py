from opyscad import *


__title__ = 'opyscad'
__version__ = '1.0'
